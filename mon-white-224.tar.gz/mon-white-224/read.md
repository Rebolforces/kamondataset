# kamon dataset

## mon-white-224

A collection of Japanese Kamon Images for use in ML generative projects.

The data was sourced from a site in web.archive. The original site no longer appears to exist.

source: web.archive.org/web/20140201015941/http://x181.secure.ne.jp/~x181007/kamon/goodslist.cgi?in_kate=&in_start=6860&max=
collected: 8-Aug-2021

Post processing:
After collecting files in gif and jpg with both white and transparent backgrounds and sizes. 

The files have all been reprocessed to be more consistent
Images were centered and placed on a white background with a fixed size of 224x224 and saved as jpg.

6425 images.

https://github.com/Rebolforces/kamondataset